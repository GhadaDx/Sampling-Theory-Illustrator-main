# Sampling-Theory-Illustrator
## Description
an illustrator for the signal recovery that shows the importance and validation of the Nyquist rate.

## Features
- signal composer to generate signals.

- sample the given signal and see the sampled points highlighted on top of the signal.

- change the sampling rate via a slider.

## Demos

https://user-images.githubusercontent.com/42315079/157133540-70b0fe25-5d77-4dc9-9272-421bc941c098.mp4

